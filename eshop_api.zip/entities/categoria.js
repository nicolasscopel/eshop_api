class Categoria {
    constructor(codigo,nome){
        this.codigo = codigo;
        this.nome = nome;
    }
}

module.exports = Categoria;